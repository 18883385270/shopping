<template>
  <div>
    <mi-header title="联盟管理"></mi-header>
    <div class="emptybox">
      <svg>
        <use xlink:href="#partnerline"></use>
      </svg>
      <p>即将上线，敬请期待</p>
    </div>
  
  </div>
</template>

<script>
import header from '../../components/header.vue';

export default {
  components: {
    'mi-header': header
  }
}
</script>


<style lang="less" scoped>

</style>

