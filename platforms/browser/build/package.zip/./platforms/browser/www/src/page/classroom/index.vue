<template>
  <div>
    <mi-header title="五福课堂"></mi-header>
    <div class="emptybox">
      <svg>
        <use xlink:href="#classroom"></use>
      </svg>
      <p>即将上线，敬请期待</p>
      <p>在线课堂，讲座，PPT</p>
    </div>
  
  </div>
</template>

<script>
import header from '../../components/header.vue';

export default {
  components: {
    'mi-header': header
  }
}
</script>


<style lang="less" scoped>

</style>

