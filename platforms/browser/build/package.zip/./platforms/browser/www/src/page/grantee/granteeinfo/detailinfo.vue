<template>
    <div class="statisticwarp">
        <div class="head">
            <div class="title">项目详情</div>
        </div>
        <div class="descwarp">
            这是黑王子你们信吗？特么这是想上天的节奏啊，叶片带大，三年了，现在还在育苗盘里，从来没换土也没施肥，也从来没有浇过水，天生天养。 这是黑王子你们信吗？特么这是想上天的节奏啊，叶片带大，三年了，现在还在育苗盘里，从来没换土也没施肥，也从来没有浇过水，天生天养。 这是黑王子你们信吗？特么这是想上天的节奏啊，叶片带大，三年了，现在还在育苗盘里，从来没换土也没施肥，也从来没有浇过水，天生天养。
            <div class="readmore">查看全文</div>
            <div class="pics">
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
                <img src="https://i8.mifile.cn/v1/a1/38f1fa24-815b-c6a6-925f-65460ce541e4.webp?width=360&height=360" />
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>


<style lang="less" scoped>
.statisticwarp {
    border-top: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
    background: #fff;
    margin-top: 1.2rem;
    .head {
        border-bottom: 1px solid #ddd;
        width: 100%;
        .title {
            font-size: 1.3rem;
            line-height: 2rem;
            padding: 1rem;
        }
    }
    .descwarp {
        padding: 1rem;color:#999;font-size: 1rem;
        .readmore {
            color: green;
            text-align: center;
            padding:0.5rem 0;
        }
        .pics {
            img {
                width: 22.5%;
                margin-right: 3.3%;margin-top:3.3%;
                &:nth-child(4n+0) {
                    margin-right: 0;
                }
            }
        }
    }
}
</style>

